package com.skrrrrr.harudam.common.enums;

public enum UserState {
	PENDING,	//비활성화
	ACTIVE,		//활성화
	INACTIVE	//이용중지
}
