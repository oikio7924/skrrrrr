package com.skrrrrr.harudam.common.enums;

public enum ScheduleCategory {
	HOSPITAL,
	MEDICATION,
	PHONE_CALL,
	APPOINTMENT,
	ETC
}
