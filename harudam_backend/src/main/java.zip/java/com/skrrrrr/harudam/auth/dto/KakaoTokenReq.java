package com.skrrrrr.harudam.auth.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class KakaoTokenReq {
	private String accessToken;
}
