
package com.skrrrrr.harudam.common.enums;

public enum SocialLogin {
	KAKAO,
	GOOGLE,
	NAVER,
}
