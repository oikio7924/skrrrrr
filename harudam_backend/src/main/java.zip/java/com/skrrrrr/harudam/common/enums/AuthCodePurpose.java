package com.skrrrrr.harudam.common.enums;

public enum AuthCodePurpose {
	SIGNUP,		// 회원가입용
	LOGIN,		// 로그인/재인증용
	RESET		// 비밀번호 초기화용
}
