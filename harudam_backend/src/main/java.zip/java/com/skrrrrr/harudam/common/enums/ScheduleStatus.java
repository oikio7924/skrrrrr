
package com.skrrrrr.harudam.common.enums;

public enum ScheduleStatus {
	PLANNED,
	DONE,
	CANCELED,
	SNOOZED
}
