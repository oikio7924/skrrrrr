package com.skrrrrr.harudam.common.enums;

public enum EmotionWord {
	HAPPY,
	NEUTRAL,
	SAD,
	ANGRY,
	ANXIOUS,
	CALM,
	SUPRRISED
}