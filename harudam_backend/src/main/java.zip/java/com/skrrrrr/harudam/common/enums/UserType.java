
package com.skrrrrr.harudam.common.enums;

public enum UserType {
	PARENT,
	CHILD
}
