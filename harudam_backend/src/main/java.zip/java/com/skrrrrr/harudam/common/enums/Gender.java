package com.skrrrrr.harudam.common.enums;

public enum Gender {
	M,
	F
}